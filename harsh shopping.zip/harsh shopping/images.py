
from tkinter import *


def dec():
    root.destroy()
    import mainpage1


root=Tk()



root.config(background="black")
root.geometry("1600x800+0+0")
root.title("Welcome To complex")

img=PhotoImage(file="D:\software\\amazon\photos\\1.png")
Label(root,image=img).place(x=100,y=150)

img1=PhotoImage(file="D:\software\\amazon\photos\\2.png")
Label(root,image=img1).place(x=100,y=450)

img2=PhotoImage(file="D:\software\\amazon\photos\\3.png")
Label(root,image=img2).place(x=900,y=150)

img3=PhotoImage(file="D:\software\\amazon\photos\\4.png")
Label(root,image=img3).place(x=900,y=450)               


Label(root,text="Some Glimpses Of The Products",bg="black",fg="white",font=("Algerian",40,"underline")).place(x=330,y=0)

Label(root,text="WE PROVIDE THE ",bg="black",fg="White",font=("Algerian",30)).place(x=470,y=150)
Label(root,text="LATEST VERSIONS",bg="black",fg="White",font=("Algerian",30)).place(x=470,y=240)
Label(root,text="OF ",bg="black",fg="White",font=("Algerian",30)).place(x=580,y=330)

Label(root,text="EVERY PRODUCT ",bg="black",fg="White",font=("Algerian",30)).place(x=470,y=420)

menubar=Menu(root)
amenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Home",menu=amenu)
amenu.add_command(label="Home",command=dec)

root.config(menu=menubar)






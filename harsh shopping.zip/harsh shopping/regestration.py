from tkinter import *
import mysql.connector

root=Tk()

def regis():
    a=str(e1.get())
    b=str(e2.get())
    c=str(e3.get())
    d=str(e4.get())
    e=str(e5.get())
    f=str(e6.get())
    conn=mysql.connector.connect(host="localhost",user="root",password="",db="registration")
    cursor=conn.cursor()
    cursor.execute("insert into registration(Fullname,emailid,DOB,username,password,phone)values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"')")
    root.destroy()
    import loginpage
    conn.commit()
    

    

root.config(background="blue")
root.geometry("600x600+350+100")
root.title("Registration Page")

Label(root,text="Full Name",bg="blue",fg="white",font=("Algerian",20)).grid(row=0,column=0)
Label(root,text="Enter e-mail id",bg="blue",fg="white",font=("Algerian",20)).grid(row=1,column=0)
Label(root,text="Enter date of birth",bg="blue",fg="white",font=("Algerian",20)).grid(row=2,column=0)
Label(root,text="create username",bg="blue",fg="white",font=("Algerian",20)).grid(row=3,column=0)
Label(root,text="create password",bg="blue",fg="white",font=("Algerian",20)).grid(row=4,column=0)
Label(root,text="Enter phone",bg="blue",fg="white",font=("Algerian",20)).grid(row=5,column=0)
e1=Entry(root)
e1.grid(row=0,column=1)
e2=Entry(root)
e2.grid(row=1,column=1)
e3=Entry(root)
e3.grid(row=2,column=1)
e4=Entry(root)
e4.grid(row=3,column=1)
e5=Entry(root,show="*")
e5.grid(row=4,column=1)
e6=Entry(root,)
e6.grid(row=5,column=1)

Button(root,text="Submit",fg="red",font=("Algerian"),command=regis).grid(row=6,column=1)

root.mainloop()

from tkinter import *
import mysql.connector
from tkinter import messagebox



def regis():
    
    import regestration


def log():
    import loginpage


def cont():
    import contact

def list():
    import list

def lis():
    import list2
    
def image():
    root.destroy()
    import images

root=Tk()


root.config(background="Black")
root.title("MenuBar")
root.geometry("1600x800+0+0")

img=PhotoImage(file="D:\software\\amazon\jjj.png")
Label(root,image=img).place(x=450,y=150)


Label(root,font=('Algerian',50,'bold',"underline"),text="Harsh Shopping complex",fg="white",bg="Black").place(x=275,y=400)




menubar=Menu(root)
fmenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Category",menu=fmenu)
fmenu.add_command(label="Electronic",command=list)
fmenu.add_command(label="furniture",command=lis)
fmenu.add_separator()

amenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Your Account",menu=amenu)
amenu.add_command(label="Old Costumer",command=log)
amenu.add_separator()
amenu.add_command(label="New Costumer",command=regis)






smenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="About Us",menu=smenu)

smenu.add_command(label="Overview of products",command=image)
smenu.add_command(label="Contact Us",command=cont)
root.config(menu=menubar)


root.mainloop()

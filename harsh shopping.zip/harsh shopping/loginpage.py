from tkinter import *
import mysql.connector

root=Tk()

def login():
    conn=mysql.connector.connect(host="localhost",user="root",password="",db="registration")
    cursor=conn.cursor()
    cursor.execute("select * from registration where username='"+e1.get()+"' and password='"+e2.get()+"'")
    if(cursor.fetchone()):
        root.destroy()
        import hello

root.config(background="blue")
root.geometry("600x600+350+100")
root.title("My Account")

Label(root,text="Username",bg="blue",fg="white",font=("Algerian",20)).grid(row=0,column=0)
Label(root,text="Password",bg="blue",fg="white",font=("Algerian",20)).grid(row=1,column=0)
e1=Entry(root)
e1.grid(row=0,column=1)
e2=Entry(root,show="*")
e2.grid(row=1,column=1)
Button(root,text="Login",fg="red",font=("Algerian"),command=login).grid(row=2,column=1)


Button(root,text="Signup",fg="red",font=("Algerian")).grid(row=2,column=2)

root.mainloop()

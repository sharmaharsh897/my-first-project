from tkinter import *

root=Tk()

root.config(background="blue")
root.geometry("1600x800+0+0")
root.title("Welcome To complex")

Label(root,text="Contact us at amazon@gmail.com ",bg="blue",fg="white",font=("Algerian",20)).grid(row=0,column=0)


